# 🛠️ shop-chat-agent

AI-powered Shopify chat assistant. Built with the Shopify CLI, Remix, and now deployed with Railway.

## 🚀 Setup on Railway

1. Set environment variables in Railway:
```
SHOPIFY_API_KEY=
SHOPIFY_API_SECRET=
SCOPES=read_products,write_products
SHOP=
REDIRECT_URL=https://your-railway-url.com/auth/callback
```

2. Update `shopify.app.toml`:
```
application_url = "https://your-railway-url.com"
[mcp.customer_authentication]
redirect_uris = [ "https://your-railway-url.com/auth/callback" ]
[auth]
redirect_urls = [ "https://your-railway-url.com/api/auth" ]
```

## 🧪 Local Dev
```bash
npm install
npm run dev
```

## 🔧 Theme App Extension

Ensure the extension files are located in:
```
extensions/chat-bubble/
```

Include:
- `chat-bubble.liquid` in `blocks/`
- `chat-bubble.js` and `chat-bubble.css` in `assets/`

## 📚 References
- [Shopify CLI](https://shopify.dev/docs/apps/tools/cli)
- [Remix for Shopify](https://shopify.dev/docs/apps/tools/remix)
- [Railway Docs](https://docs.railway.app)